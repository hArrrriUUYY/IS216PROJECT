<?php
require_once('bootstrap.php');
require_once('entities/gyms.php');
$query= $entityManager->createQuery('SELECT g FROM Gym g');
$gym = $query->getResult();

$gymArr = array();

for($i=0;$i<count($gym); $i++){
    $curr = $gym[$i];
    $name = $curr->getName();
    $price = $curr->getPrice();
    $arrOfKeyandValue = array('name' => $name, 'price' => $price);
    $gymJson = json_encode($arrOfKeyandValue);
    array_push($gymArr, $gymJson);//this will add each of the json stuff to the array

}

echo json_encode($gymArr);



?>