<?php
require_once('bootstrap.php');
require_once('entities/users.php');
$query= $entityManager->createQuery("SELECT u FROM Users u");
$users = $query->getResult();


$usersArr=[];


for($i=0;$i<count($users); $i++){
    $curr = $users[$i];
    $name = $curr->getName();
    $height = $curr->getHeight();
    $weight = $curr->getWeight();
    $cutOrBulk = $curr->getCutOrBulk();
    $email = $curr->getEmail();

    $arrOfKeyandValue = array('name' => $name, 'height' => $height, 'weight' => $weight, 'cutOrBulk' => $cutOrBulk,'email' => $email); // array of obj
    $userJson = json_encode($arrOfKeyandValue); //convert obj to json
    array_push($usersArr, $userJson);//this will add each of the json stuff to the array

}

echo json_encode($usersArr);