<?php
require_once('bootstrap.php');
require_once('entities/product.php');
$query= $entityManager->createQuery("SELECT p FROM Product p");
$product = $query->getResult();


$productArr=[];


for($i=0;$i<count($product); $i++){
    $curr = $product[$i];
    $name = $curr->getName();
    $calories = $curr->getCalories();
    $protein = $curr->getProtein();
    $mealOfDay = $curr->getMealOfDay();
    $recipeLink = $curr->getRecipeLink();
    $imgLink = $curr->getImgLink();

    $arrOfKeyandValue = array('name' => $name, 'calories' => $calories, 'protein'=>$protein, 'mealOfDay' => $mealOfDay, 'recipeLink'=> $recipeLink, 'imgLink'=>$imgLink); // array of obj
    $prodJson = json_encode($arrOfKeyandValue); //convert obj to json
    array_push($productArr, $prodJson);//this will add each of the json stuff to the array

}

echo json_encode($productArr);