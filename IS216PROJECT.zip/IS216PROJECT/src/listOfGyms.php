<?php
require_once('bootstrap.php');
require_once('entities/gyms.php');

global $entityManager;

$gym1 = new Gym("Anytime Fitness", 105);
$gym2 = new Gym("Virgin Active", 300);
$gym3 = new Gym("Gym Boxx", 105);
$gym4 = new Gym("True Fitness", 90);
$gym5 = new Gym("Fitness First", 140);

$gymReview1_1 = new GymReview($gym1, "Great facilities");
$gymReview1_2 = new GymReview($gym1, "Clean and affordable, good enough for me");
$gymReview1_3 = new GymReview($gym1, "A very nice gym with a very decent free weights area with 2 power racks with platforms, a half rack, coloured bumper plates");
$gymReview1_4 = new GymReview($gym1, "My first time experience at this gym, the staff were really helpful in showing me the different equipments and were quick to answer all my questions. Overall, I had an excellent experience and would come back in the near future.");
$gymReview1_5 = new GymReview($gym1, "Awesome place. Cozy and packed with good equipments!");


$gymReview2_1 = new GymReview($gym2, "Love the smell of expensive air");
$gymReview2_2 = new GymReview($gym2, "Wide range of facilities, you'll get a good spa day here");
$gymReview2_3 = new GymReview($gym2, "Super big! Much bigger than other locations. Equipment nicely spaced out. Clean too. Staff were all very friendly. Went at 6pm but it was still very adequately spaced out / socially distanced");
$gymReview2_4 = new GymReview($gym2,"Beginner friendly! The environment is nice too with sufficient space for everyone");
$gymReview2_5 = new GymReview($gym2,"Just bring your favorite active shoes with you.  Gears, socks, towels and toiletries are provided but feel free show us your own style if you like!");

$gymReview3_1 = new GymReview($gym3,"Great place to have a workout, make use of the year end discount while you still can. The view of the mrt is really nice while doing cardio. The only downside is that the shower facilities does not have a basin for washing and no urinals. Overall, great ambience and good overall staff.");
$gymReview3_2 = new GymReview($gym3, "Very affordable gym, a lot of quality equipment, friendly staff and great atmosphere. More bodybuilding oriented than Fitness First or other gyms in Singapore.");
$gymReview3_3 = new GymReview($gym3,"Affordable, wide range of equipment and free weights. Suitable for powerlifters, weightlifters, bodybuilders and casual gym goers. The staff is friendly and helpful too. Only downside is the repetitive music...");
$gymReview3_4 = new GymReview($gym3, "Give it a try but very disappointing. Not a good environment to have your gym as in the night time the gym is packed with people. The counter registration service is not very friendly . I was not aware of bringing the towel to the gym , because my other gym membership provides towel. Towel quality is so bad and cant even been use so is pointless.");
$gymReview3_5 = new GymReview($gym3,"Equipments are nice and clean, they also have 25 kg plates and 4 racks for squats");

$gymReview4_1 = new GymReview($gym4,"Best gym equipment with great view. Would recommend this gym");
$gymReview4_2 = new GymReview($gym4,"cancelled almost all the off-peak hour classes, leaving only limited classes in early morning. Massive ocst-cutting exercise and many members are very unhappy");
$gymReview4_3 = new GymReview($gym4,"Equipment is old and very limited on leg weights");
$gymReview4_4 = new GymReview($gym4,"I love the environment of the location and the workout was great the customer service representative was given their 100% service to their client");
$gymReview4_5 = new GymReview($gym4,"Nice facilities! Electronic locker and well designed shower cubicles are great! Love the view too!");

$gymReview5_1 = new GymReview($gym5,"Come here to gym often! Stuff is really clean and absolutely love the pool area!");
$gymReview5_2 = new GymReview($gym5,"The receptionists are kind and helpful.");
$gymReview5_3 = new GymReview($gym5,"Love the gym as the pool is usually clean and not too crowded. The gym itself is also very spacious and good for safe distancing.");
$gymReview5_4 = new GymReview($gym5,"I really love the pool! Probably one of the best among fitness first branch. The gym itself is quite packed, so other than the pool, it could be a little uncomfortable when it’s crowded.");
$gymReview5_5 = new GymReview($gym5,"Amazing view while working out. Peak hours not bad at all.");




$arr = [$gym1, $gym2, $gym3, $gym4, $gym5, $gymReview1_1, $gymReview1_2, $gymReview1_3, $gymReview1_4, $gymReview1_5, $gymReview2_1, $gymReview2_2,$gymReview2_3,$gymReview2_4,$gymReview2_5, $gymReview3_1,$gymReview3_2,$gymReview3_3,$gymReview3_4, $gymReview3_5, $gymReview4_1,$gymReview4_2,$gymReview4_3,$gymReview4_4,$gymReview4_5, $gymReview5_1, $gymReview5_2, $gymReview5_3, $gymReview5_4, $gymReview5_5];

for($i=0;$i<count($arr);$i++){
    $entityManager->persist($arr[$i]);
}
$entityManager->flush();

?>