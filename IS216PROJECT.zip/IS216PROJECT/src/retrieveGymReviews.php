<?php
require_once('bootstrap.php');
require_once('entities/gyms.php');
$query= $entityManager->createQuery('SELECT g FROM Gym g');
$gym = $query->getResult();

$reviewsByEachGym=[];

for($i=0;$i<count($gym); $i++){
    $curr = $gym[$i];
    $reviews = $curr->getReviews();
    $allReviewsbyEachGym=[];
    
    for($j=0;$j<count($reviews);$j++){
        array_push($allReviewsbyEachGym, $reviews[$j]->getReview());
    }
    $eachGym = array ('name'=>$curr->getName(), 'reviews' =>$allReviewsbyEachGym);
    array_push($reviewsByEachGym, $eachGym);

}

echo json_encode($reviewsByEachGym)




?>