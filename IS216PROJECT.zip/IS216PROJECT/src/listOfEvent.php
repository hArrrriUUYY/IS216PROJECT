<?php
require_once('entities/events.php');
require_once('bootstrap.php');
global $entityManager;

$event1 = new Event("MetaMonsters 5k Run", "26 Oct 8am-10am -- MetaMonsters is a 5km Run held annually at Singapore Botanics Garden and is free for all to sign up!", "https://static.wixstatic.com/media/6d7659_42aac7a8cf0644769b223bed8f4722b8~mv2.png/v1/fill/w_1434,h_712,al_c/6d7659_42aac7a8cf0644769b223bed8f4722b8~mv2.png", "https://www.eventbrite.sg/e/metamonsters-5k-run-tickets-386265479447?aff=ebdssbdestsearch");
$event2 = new Event("NUS Medicine Walk and Run", "5 Nov 11am-1pm -- Inspiring health for all! Challenge yourself with a 3km walk/run and see how far you can go!", "https://images.weserv.nl/?url=https://virtual-race-submissions.s3-ap-southeast-1.amazonaws.com/images/Landing-Page-jpg-3x001082022-92710", "https://web.42race.com/race-bundle/nusmed2022");
$event3 = new Event("Limitless Run 2022", "10 Nov 7am-9.30am -- Limitless Run is an annual run where we raise funds for youth mental health programmes!", "https://images.squarespace-cdn.com/content/v1/59251f1cf5e2312a3e6144a5/9132ecbb-5ce6-461c-95e0-8547196cb20c/EDM_TLR2022_600%C3%97400.png?format=1000w", "https://connect.justrunlah.com/virtual-challenge/the-limitless-run-2022/");
$event4 = new Event("Skechers Friendship Walk 2022", "27 Nov 9am-11am -- Skechers Friendship Walk is held for the fifth consecutive year to encourage bonding between friends and families while staying fit outdoors.", "https://heyjom-production-assets.s3.ap-southeast-1.amazonaws.com/event-sections%2Fskechers2022%2FWalk+Kit+Collection.jpg","https://web.42race.com/race-bundle/skechersfw2022");
$event5 = new Event("Ride for Rainbows", "27 Nov 12pm-3pm -- Ride for Rainbows is a flagship annual cycling fundraising event organised by Club Rainbow. The event hopes to raise awareness and support children with major chronic and potentially life-threatening illness.", "https://images.squarespace-cdn.com/content/v1/552e430de4b036b38b3f0f45/1659502158370-N70CTAYEJGEE9XYE3M4X/1920x1080-02.jpg?format=1000w", "https://www.rideforrainbows.org/signup");
$event6 = new Event("Standard Chartered Singapore Marathon 2022","3 Dec 7pm-9pm -- The Standard Chartered Singapore Marathon (SCSM) is back! Compete in the half marathon (21.1km) and marathon (42.195km) categories.","
https://circle.myactivesg.com/hubfs/SCSM_Launch%20%283%29.png", "https://endurancecui.active.com/new/events/81244634/select-race?error=login_required&state=519e5370-cb27-49a9-9ebe-75abb97dfada&_p=9945664470912468&e4q=60756fcc-44b6-4236-84d6-2333baee33aa&e4p=6619d099-9294-4b3f-992f-699a979a9b1b&e4ts=1667901137&e4c=active&e4e=snawe00000000&e4rt=Safetynet&e4h=6117724dc3c159698d8e573ae9ed3dc3");
$event7 = new Event("Changi Run 2023", "1 Jan 9am-12pm -- Organised by Changi General Hospital (CGH), join the event by taking part in the 5km run at East Coast Park.", "https://www.justrunlah.com/wp-content/uploads/2022/09/CR23-cover01b.jpg", "https://connect.justrunlah.com/changi-run-2023-virtual/?campaign=JRLButtonRacePage");

$arr =[$event1, $event2, $event3, $event4, $event5, $event6, $event7];
for($i=0; $i<count($arr);$i++){
    $entityManager->persist($arr[$i]);
}
$entityManager->flush();

?>