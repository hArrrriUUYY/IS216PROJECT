<?php

require_once('bootstrap.php');
require_once('entities/users.php');
$_POST = json_decode(file_get_contents("php://input"),true);
global $entityManager;

$email = $_POST['email'];
$h = $_POST['height'];
$w= $_POST['weight'];
$cOrB = $_POST['cutOrBulk'];
$n= $_POST['name'];
$pw = $_POST['password'];
$pwHashed = password_hash($pw,PASSWORD_DEFAULT);




$user = new Users($email,$h,$w,$cOrB,$n, $pwHashed);
$entityManager->persist($user);
$entityManager->flush();

$result = [];
$result['message'] = "msg";
$postJSON = json_encode($result);
echo $postJSON;
?>