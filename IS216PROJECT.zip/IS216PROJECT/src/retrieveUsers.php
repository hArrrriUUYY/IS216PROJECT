<?php
require_once('bootstrap.php');
require_once('entities/users.php');
$query= $entityManager->createQuery("SELECT u FROM Users u");
$users = $query->getResult();


$usersArr=[];


for($i=0;$i<count($users); $i++){
    $curr = $users[$i];
    $email = $curr->getEmail();
    $password = $curr->getPassword();

    $arrOfKeyandValue = array('email' => $email, 'password' => $password); // array of obj
    $userJson = json_encode($arrOfKeyandValue); //convert obj to json
    array_push($usersArr, $userJson);//this will add each of the json stuff to the array

}

echo json_encode($usersArr);