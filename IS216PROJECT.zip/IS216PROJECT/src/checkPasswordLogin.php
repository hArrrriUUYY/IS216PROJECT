<?php
require_once('bootstrap.php');
require_once('entities/users.php');
$_POST = json_decode(file_get_contents("php://input"),true);
$e=$_POST['email'];
$query= $entityManager->createQuery("SELECT u FROM Users u WHERE u.email = :email")->setParameters(['email'=>$e]);

$user = $query->getResult()[0];


$pw = $_POST['password'];


$cutOrBulk = $user->getCutOrBulk();
$name = $user->getName();

if(checkPW($user,$pw, $e)==true){
    session_start();
    $_SESSION['name'] = $name;
    $_SESSION['cutOrBulk'] = $cutOrBulk;
    $_SESSION['email'] = $e;
    $bool =true;
    $output = array('name' => $name, 'cutOrBulk' => $cutOrBulk , 'email' => $e, 'bool'=>$bool);
    echo JSON_encode($output);
}else{
    $bool= false;
    $output = array('name' => $name, 'cutOrBulk' => $cutOrBulk , 'email' => $e, 'bool'=>$bool);
    echo JSON_encode($output);
}


function checkPW($user,$pw, $e){
   
    if(($user->getEmail())==$e){
        if(password_verify($pw,$user->getPassword())==true){
            return true;
        }else{
            return false;
        }
    }else{
        return false;
    }

}




?>