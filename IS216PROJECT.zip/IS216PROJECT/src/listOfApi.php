<?php
require_once('entities/apikeys.php');
require_once('bootstrap.php');
global $entityManager;

$api1 = new Api(1, "Google", "AIzaSyCSXd4i0feXJ5l1Nw1z8N3xwLGft26VwdU");
$api2 = new Api(2, "Workout", "LWC81By67BBn2tP5k99ETQ==0uWvLqlvv7SN7hRz");
$api3 = new Api(3, "Youtube", "AIzaSyDvOZ1_QTcgmWqu0QucdyqsVCRZGQLKkDY");
$api4 = new Api(4, "Youtube", "AIzaSyCvKgGP-8B8JmoVfV07NJRsVXdiTggaJmY");
$api5 = new Api(5, "Youtube", "AIzaSyBHXdbjXr8UcVOKRvr5BTW_ovFwK73CGFg");
$api6 = new Api(6, "Youtube", "AIzaSyAPtQB6UOcJ26vSI25RVwJ9maZSb0Qwhtc");
$api7 = new Api(7, "Youtube", "AIzaSyDHQE5q8GgVdo23fQJPaCbEfFy7uEadqTQ");


$arr =[$api1, $api2, $api3, $api4, $api5, $api6, $api7];
for($i=0; $i<count($arr);$i++){
    $entityManager->persist($arr[$i]);
}
$entityManager->flush();

?>