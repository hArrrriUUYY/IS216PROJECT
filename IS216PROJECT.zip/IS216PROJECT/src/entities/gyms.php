<?php
 
use Doctrine\ORM\Mapping as ORM;


/** @ORM\Entity() */
class Gym
{
    /** @ORM\Id @ORM\Column(type="string", length=140) */
    private $name;
    /** @ORM\Column(type="string", length=140) */
    private $price;
    /**
     * One product has many features. This is the inverse side.
     * @ORM\OneToMany(targetEntity="GymReview", mappedBy="gym")
     */
    private $reviews;

    public function __construct($name,$price) {
        $this->name = $name;
        $this->price = $price;
        $this->reviews = [];
      }

    public function getName()
    {
        return $this->name;
    }

    public function getPrice()
    {
        return $this->price;
    }

    public function getReviews(){
        return $this->reviews;
    }
}

/** @ORM\Entity() */
class GymReview
{
    /** @ORM\Id @ORM\Column(type="integer") @ORM\GeneratedValue(strategy="AUTO")*/
    private $id;
    /**
     * Many features have one product. This is the owning side.
     * @ORM\ManyToOne(targetEntity="Gym", inversedBy="reviews")
     * @ORM\JoinColumn(name="gymName", referencedColumnName="name")
     */
    private $gym;
    /** @ORM\Column(type="string", length=1000) */
    private $review;

    public function __construct($gym,$review) {
        $this->gym = $gym;
        $this->review = $review;
      }

    public function getGym()
    {
        return $this->gym;
    }

    public function getReview()
    {
        return $this->review;
    }

}
?>