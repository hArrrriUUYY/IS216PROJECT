<?php

use Doctrine\ORM\Mapping as ORM;

/** @ORM\Entity() */
class Event
{
    /** @ORM\Id @ORM\Column(type="string", length=140) */
    private $name;
    /** @ORM\Column(type="string", length=300) */
    private $info;
    /** @ORM\Column(type="string", length=500) */
    private $posterLink;
    /** @ORM\Column(type="string", length=500) */
    private $regUrl;

    public function __construct($name,$info, $posterLink, $regUrl) {
        $this->name = $name;
        $this->info = $info;
        $this->posterLink= $posterLink;
        $this->regUrl = $regUrl;
      }

    public function getName()
    {
        return $this->name;
    }

    public function getInfo()
    {
        return $this->info;
    }
    public function getPosterLink()
    {
        return $this->posterLink;
    }

    public function getRegUrl()
    {
        return $this->regUrl;
    }
}
?>