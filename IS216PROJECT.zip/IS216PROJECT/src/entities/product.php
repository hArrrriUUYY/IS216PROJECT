<?php

use Doctrine\ORM\Mapping as ORM;

/** @ORM\Entity() */
class Product
{
    /** @ORM\Id @ORM\Column(type="string", length=140) */
    private $name;
    /** @ORM\Column(type="float") */
    private $calories;
    /** @ORM\Column(type="float") */
    private $protein;
    /** @ORM\Column(type="string", length=20) */
    private $cutOrNot;
    /** @ORM\Column(type="string", length=20) */
    private $mealOfDay;
    /** @ORM\Column(type="string", length=500) */
    private $recipeLink;
    /** @ORM\Column(type="string", length=500) */
    private $imgLink;

    public function __construct($name,$calories,$protein, $cutOrNot, $mealOfDay, $recipeLink, $imgLink) {
        $this->name = $name;
        $this->calories = $calories;
        $this->protein = $protein;
        $this->cutOrNot = $cutOrNot;
        $this->mealOfDay = $mealOfDay;
        $this->recipeLink = $recipeLink;
        $this->imgLink = $imgLink;
    }

    public function getName()
    {
        return $this->name;
    }

    public function getCalories()
    {
        return $this->calories;
    }

    public function getProtein()
    {
        return $this->protein;
    }

    public function getCutOrGain()
    {
        return $this->cutOrNot;
    }

    public function getMealOfDay()
    {
        return $this->mealOfDay;
    }
    public function getRecipeLink()
    {
        return $this->recipeLink;
    }
    public function getImgLink()
    {
        return $this->imgLink;
    }

}