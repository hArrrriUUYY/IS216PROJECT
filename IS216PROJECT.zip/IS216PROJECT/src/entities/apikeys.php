<?php

use Doctrine\ORM\Mapping as ORM;

/** @ORM\Entity() */
class Api
{
    /** @ORM\Id @ORM\Column(type="string", length=140) */
    private $id;
    /** @ORM\Column(type="string", length=300) */
    private $category;
    /** @ORM\Column(type="string", length=300) */
    private $apiKey;

    public function __construct($id, $category, $apiKey) {
        $this->id = $id;
        $this->category = $category;
        $this->apiKey = $apiKey;
      }

    public function getId()
    {
        return $this->id;
    }

    public function getCategory()
    {
        return $this->category;
    }
    public function getApiKey()
    {
        return $this->apiKey;
    }

}
?>