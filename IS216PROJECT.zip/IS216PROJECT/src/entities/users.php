<?php

use Doctrine\ORM\Mapping as ORM;

/** @ORM\Entity() */
class Users
{
    /** @ORM\Id @ORM\Column(type="string", length=140) */
    private $email;
    /** @ORM\Column(type="float") */
    private $height;
    /** @ORM\Column(type="float") */
    private $weight;
    /** @ORM\Column(type="string", length=20) */
    private $cutOrBulk;
    /** @ORM\Column(type="string", length=55) */
    private $name;
    /** @ORM\Column(type="string", length=100) */
    private $password;

    public function __construct($email, $height, $weight, $cutOrBulk, $name, $password) {
        $this->name = $name;
        $this->height = $height;
        $this->weight = $weight;
        $this->cutOrBulk = $cutOrBulk;
        $this->password = $password;
        $this->email = $email;
      }

    public function getName()
    {
        return $this->name;
    }

    public function getHeight()
    {
        return $this->height;
    }

    public function getWeight()
    {
        return $this->weight;
    }

    public function getCutOrBulk()
    {
        return $this->cutOrBulk;
    }
    public function getEmail()
    {
        return $this->email;
    }

    public function getPassword()
    {
        return $this->password;
    }
    
    public function newUserObject($email, $height, $weight, $cutOrBulk, $name, $password){
        return new Users($email, $height, $weight, $cutOrBulk, $name, $password);
    }
};




?>