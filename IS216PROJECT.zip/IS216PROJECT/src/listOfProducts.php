<?php
require_once('bootstrap.php');
require_once('entities/product.php');

global $entityManager;

$listOfProducts = [new Product('Low-Fat Chicken Caesar Salad', 321, 48, 'CUT', 'DINNER', 'https://www.erinliveswhole.com/healthy-chicken-caesar-salad/', 'LowFatChickenCaesarSalad.jpg'),
                    new Product('Spiced Chicken, Spinach & Sweet Potato Stew', 445, 33, 'CUT', 'DINNER', 'https://www.bbcgoodfood.com/recipes/spiced-chicken-spinach-sweet-potato-stew', 'SpicedChickenSpinachSweetPotatoStew.jpg'),
                    new Product('Sesame salmon, purple sprouting broccoli & sweet potato mash', 463, 32, 'CUT', 'DINNER', 'https://www.bbcgoodfood.com/recipes/sesame-salmon-purple-sprouting-broccoli-sweet-potato-mash', 'Sesamesalmonpurplesproutingbroccolisweetpotatomash.jpg'),
                    new Product('Ham, Mushroom & Spinach Frittata', 226, 22, 'CUT', 'DINNER', 'https://www.bbcgoodfood.com/recipes/ham-mushroom-spinach-frittata', 'HamMushroomSpinachFrittata.jpg'),
                    new Product('Prawn, Fennel & Rocket Risotto', 391, 21, 'CUT', 'DINNER', 'https://www.bbcgoodfood.com/recipes/prawn-fennel-rocket-risotto', 'PrawnFennelRocketRisotto.jpg'),

                    new Product('Courgette, Pea & Pesto Soup', 206, 10, 'CUT', 'LUNCH', 'https://www.bbcgoodfood.com/recipes/courgette-pea-pesto-soup', 'CourgettePeaPestoSoup.jpg'),
                    new Product('Spicy Meatballs With Chilli Black Beans', 376, 42, 'CUT', 'LUNCH', 'https://www.bbcgoodfood.com/recipes/spicy-meatballs-chilli-black-beans', 'MeatballInSpicyBlackBeanSauce.jpg'),
                    new Product('Chipotle Chicken & Slaw', 318, 27, 'CUT', 'LUNCH', 'https://www.bbcgoodfood.com/recipes/chipotle-chicken-slaw', 'ChipotleChickenSlaw.jpg'),
                    new Product('Seared Beef Salad With Capers & Mint', 357, 29, 'CUT', 'LUNCH', 'https://www.bbcgoodfood.com/recipes/seared-beef-salad-capers-mint', 'SearedBeefSaladCapersMint.jpg'),
                    new Product('Penne With Broccoli, Lemon & Anchovies', 493, 22, 'CUT', 'LUNCH', 'https://www.bbcgoodfood.com/recipes/penne-broccoli-lemon-anchovies', 'PenneBroccoli,LemonAnchovies.jpg'),

                    new Product('Egg, Tomato, And Scallion Sandwich', 213, 13.5, 'CUT', 'BREAKFAST', 'https://www.skinnytaste.com/egg-tomato-and-scallion-sandwich/', 'EggTomatoScallionSandwich.jpg'),
                    new Product('Healthy Bacon, Egg, And Potato Breakfast Casserole', 184, 15, 'CUT', 'BREAKFAST', 'https://jeanetteshealthyliving.com/healthy-bacon-egg-potato-breakfast-casserole-recipe/', 'HealthyBaconEggPotatoBreakfastCasserole.jpg'),
                    new Product('Smoked Salmon Eggs Benedict', 388, 33.5, 'CUT', 'BREAKFAST', 'https://www.bbcgoodfood.com/recipes/eggs-benedict-smoked-salmon-chives', 'SmokedSalmonEggsBenedict.jpg'),
                    new Product('Chai Baked Oatmeal', 273, 5, 'CUT', 'BREAKFAST', 'https://www.eatingbirdfood.com/chai-baked-oatmeal/', 'Peanut-Butter-Chai-Banana-Baked-Oatmeal.jpg'),
                    new Product('Butternut Squash Protein Pancakes', 236, 5, 'CUT', 'BREAKFAST', 'https://transformationprotein.com/blogs/recipes/butternut-squash-protein-pancakes', 'Butternut_Squash_Protein_Pancakes'),
                    
                    new Product('Salmon Burgers', 480, 30, 'BULK', 'DINNER', 'https://www.savoryonline.com/recipes/salmon-burger-with-dill-cucumber-spread/', 'SalmonBurgers.jpg'),
                    new Product('Baked Caprese Chicken', 416, 46, 'BULK', 'DINNER', 'https://therecipecritic.com/baked-caprese-chicken/', 'BakedCapreseChicken.jpg'),
                    new Product('Grilled Halibut & Tomato Salsa', 456, 48, 'BULK', 'DINNER', 'https://www.food.com/recipe/grilled-halibut-with-tomato-basil-salsa-434131', 'GrilledHalibutTomatoSalsa.jpg'),
                    new Product('Chicken Tikka Masala', 507, 49, 'BULK', 'DINNER', 'https://cafedelites.com/chicken-tikka-masala/', 'ChickenTikkaMasala.jpg'),
                    new Product('Apple & Onion Pork Chops', 555, 32, 'BULK', 'DINNER', 'https://www.thechunkychef.com/one-pan-pork-chops-apples-onions/', 'AppleOnionPorkChops.jpg'),

                    new Product('Chicken Fajitas', 411, 39, 'BULK', 'LUNCH', 'https://downshiftology.com/recipes/chicken-fajitas/', 'ChickenFajitas.jpg'),
                    new Product('Greek Lemon Chicken With Tzatziki Sauce', 410, 38, 'BULK', 'LUNCH', 'https://reciperunner.com/greek-lemon-chicken-skewers-tzatziki-sauce/', 'GreekLemonChickenSkewers.jpg'),
                    new Product('Shrimp Fried Quinoa', 432, 32, 'BULK', 'LUNCH', 'https://www.cookingclassy.com/quinoa-shrimp-fried-rice/', 'ShrimpFriedQuinoa.jpg'),
                    new Product('Chimichurri Steak', 560, 47, 'BULK', 'LUNCH', 'https://www.recipetineats.com/skirt-steak-with-chimichurri-sauce/', 'ChimichurriSteak.jpg'),
                    new Product('Spicy Sesame Zoodles With Crispy Tofu', 500, 30, 'BULK', 'LUNCH', 'https://pinchofyum.com/sesame-zoodles', 'SpicySesameZoodlesCrispyTofu.jpg'),

                    new Product('Banana Pancakes', 680, 25, 'BULK', 'BREAKFAST', 'https://www.allrecipes.com/recipe/20334/banana-pancakes-i/', 'banana_pancake.jpg'),
                    new Product('Chicken Omelette', 520, 50, 'BULK', 'BREAKFAST', 'https://www.thespruceeats.com/chicken-omelets-4589770', 'Chicken-Omelette.jpg'),
                    new Product('Smashed Chickpea And Avocado Toast', 510, 20, 'BULK', 'BREAKFAST', 'https://blog.memeinge.com/avocado-chickpea-toast/', 'SmashedChickpeaAvocadoToast.jpg'),
                    new Product('Greek Yogurt With Nuts, And Berries', 645, 35, 'BULK', 'BREAKFAST', 'https://www.mealgarden.com/recipe/greek-yogurt-with-berries-nuts-and-honey/', 'GreekYogurtWithNutsBerries'),
                    new Product('Eggs And Avocado Toast', 615, 35, 'BULK', 'BREAKFAST', 'https://feelgoodfoodie.net/recipe/avocado-toast-with-egg-3-ways/', 'EggsAvocadoToast.jpg'),
                    ];

    for($i=0;$i<count($listOfProducts);$i++){
        $entityManager->persist($listOfProducts[$i]);
        $entityManager->flush();
    }




    
?>