<?php
require_once('bootstrap.php');
require_once('entities/apikeys.php');
$query= $entityManager->createQuery('SELECT a FROM Api a');
$api = $query->getResult();


$apiArr = array();

for($i=0;$i<count($api); $i++){
    $curr = $api[$i];
    $id = $curr->getId();
    $category = $curr->getCategory();
    $key = $curr->getApiKey();
  
    $arrOfKeyandValue = array('id' => $id, 'category' => $category , 'key' => $key); // array of obj
    $apiJson = json_encode($arrOfKeyandValue); //convert obj to json
    array_push($apiArr, $apiJson);//this will add each of the json stuff to the array

}

echo json_encode($apiArr)


?>