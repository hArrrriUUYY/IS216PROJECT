<?php
require_once('bootstrap.php');
require_once('entities/events.php');
$query= $entityManager->createQuery('SELECT e FROM Event e');
$event = $query->getResult();

$eventArr = array();

for($i=0;$i<count($event); $i++){
    $curr = $event[$i];
    $name = $curr->getName();
    $info = $curr->getInfo();
    $posterLink = $curr->getPosterLink();
    $regUrl = $curr-> getRegUrl();
    $arrOfKeyandValue = array('name' => $name, 'info' => $info , 'posterLink' => $posterLink, 'regUrl'=> $regUrl); // array of obj
    $eventJson = json_encode($arrOfKeyandValue); //convert obj to json
    array_push($eventArr, $eventJson);//this will add each of the json stuff to the array

}

echo json_encode($eventArr);

?>